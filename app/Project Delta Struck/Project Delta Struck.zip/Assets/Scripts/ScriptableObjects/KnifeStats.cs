﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[System.Serializable]
public class KnifeStats
{
    public float Price = 100f;
    public float Damage = 1f;
}
