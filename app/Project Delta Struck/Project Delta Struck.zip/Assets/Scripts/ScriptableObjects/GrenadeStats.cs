﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[System.Serializable]
public class GrenadeStats
{
    public float ExplosionRadius = 1f;
    public float Price = 100f;
    public float Damage = 1f;
}
