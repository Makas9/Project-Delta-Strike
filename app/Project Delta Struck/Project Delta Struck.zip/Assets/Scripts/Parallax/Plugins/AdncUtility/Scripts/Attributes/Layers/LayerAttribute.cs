﻿using UnityEngine;

namespace Adnc.Utility {
    public class LayerAttribute : PropertyAttribute {
    }
}
