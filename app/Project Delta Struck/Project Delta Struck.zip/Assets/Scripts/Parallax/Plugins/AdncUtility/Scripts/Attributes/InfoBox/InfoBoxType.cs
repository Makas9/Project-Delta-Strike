﻿namespace Adnc.Utility {
    public enum InfoBoxType {
        None,
        Info,
        Warning,
        Error
    }
}