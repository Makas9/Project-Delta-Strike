﻿namespace Adnc.Utility {
    public enum ShowToggleDisplay {
        Show,
        Hide,
        Disable
    }
}