﻿using UnityEngine;

namespace Adnc.Utility {
    public class TagAttribute : PropertyAttribute {
    }
}