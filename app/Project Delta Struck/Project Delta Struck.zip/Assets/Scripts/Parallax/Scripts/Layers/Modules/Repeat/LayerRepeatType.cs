﻿namespace Adnc.QuickParallax.Modules {
    public enum LayerRepeatType {
        XAxis,
        YAxis,
        Both
    }
}