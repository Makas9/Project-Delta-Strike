﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
[System.Serializable]
public class VestStats
{
    public float Price = 1f;
    public float Resistence = 1f;
}
