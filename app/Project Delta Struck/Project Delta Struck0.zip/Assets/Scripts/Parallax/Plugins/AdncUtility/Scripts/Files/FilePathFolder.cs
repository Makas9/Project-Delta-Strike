﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Adnc.Utility.Files {
    [System.Serializable]
    public class FilePathFolder : FilePathBase {
    }
}
