﻿using UnityEngine;

namespace Adnc.Utility {
    public class SortLayerAttribute : PropertyAttribute {
    }
}